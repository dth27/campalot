package is.hi.service;

import org.springframework.stereotype.Service;

import java.util.Date;


public interface AlternativeService {

    public Date dateMaker(String date);
}
